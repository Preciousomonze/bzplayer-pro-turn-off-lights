# bzplayer-pro-turn-off-lights WordPress Plugin
bzplayer-pro Turn Off the lights Wordpress Plugin
It adds a "turn off the light " feature when videos from bzplayer-pro plugin are played.
Also supports video elements in a div(or any element) that has a class named "video-js", i guess those are videos powered by video js.
Only supports the all videos with html5 video feature apart from videos from youtube,vimeo links embeded with iframe, tired of typing jare.

## How to Use

#### 1 - Upload & Activate Plugin

Download the zip file or download this repo and zip it, and upload either through 
- ftp/cpanel to "wp-content/plugins/".
- the WordPress dashboard in "plugin > add new" page. 
- Activate the plugin and you're good to go.
It's installed the normal way an external plugin is installed

#### That's All, things should work fine. :)
